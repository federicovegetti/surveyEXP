# Function to coefficients (with option to get odds ratio from logistic models and clustered SEs (with VCOV matrix calculated previously))
extr_coef <- function(x, oddr = F, cluster = F, vcov = NULL){
  
  if(sum(c("glm", "lm", "polr", "coeftest") %in% class(x)) > 0){
    
    out <- data.frame(
      names(coef(x)),
      coef(x),
      confint(x),
      row.names = NULL
    )
    
    names(out) <- c("ivs", "beta", "lo", "hi")
    
  } else if(class(x) == "glmmTMB"){
    
    temp <- confint(x)
    out <- data.frame(
      rownames(temp),
      temp[, 3],
      temp[, 1],
      temp[, 2],
      row.names = NULL
    )
    names(out) <- c("ivs", "beta", "lo", "hi")
    out <- out %>% 
      filter(grepl("Std\\.Dev\\.", ivs) == F) %>% 
      data.frame()
    
  } else if(class(x) == "clmm"){
    
    out <- data.frame(
      names(coef(x)),
      coef(x),
      confint(x),
      row.names = NULL
    )
    names(out) <- c("ivs", "beta", "lo", "hi")
    
  }
  
  if(oddr == T){
    
    out %>% 
      mutate(across(c(beta, lo, hi), ~exp(.))) %>% 
      data.frame()
    
  } else {
    
    data.frame(out)
    
  }
  
}

